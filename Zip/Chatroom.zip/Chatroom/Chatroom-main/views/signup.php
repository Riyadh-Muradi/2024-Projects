<h1>signup</h1>
<form action="signup-process" method="post">
    <div>
        <label for="username">username</label>
        <input type="text" name="username" id="username">
        <label for="password">password</label>
        <input type="password" name="password" id="password">
        <label for="password_confirmation">confirm password</label>
        <input type="password" name="password_confirmation" id="password_confirmation">
        <button type="submit">signup</button>
    </div>
</form>
